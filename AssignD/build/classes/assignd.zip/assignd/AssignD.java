/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignd;

/**
 *
 * @author T4d3
 */
public class AssignD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("D16---------------");
        ClassD16 classD16 = new ClassD16();
//        classD16.go();

        System.out.println("D17---------------");
        ClassD17 classD17 = new ClassD17();
//        classD17.go();

        System.out.println("D18---------------");
        ClassD18 classD18 = new ClassD18();
        classD18.go();

        System.out.println("D19---------------");
        ClassD19 classD19 = new ClassD19();
        classD19.go();
    }
}