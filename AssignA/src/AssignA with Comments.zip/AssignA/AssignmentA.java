/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AssignA;

/**
 *
 * @author T4d3
 */
public class AssignmentA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println("A1---------------");
        ClassA1 classA1 = new ClassA1();

        System.out.println("A2---------------");
        ClassA2 classA2 = new ClassA2();

        System.out.println("A3---------------");
        ClassA3 classA3 = new ClassA3();

        System.out.println("A4---------------");
        ClassA4 classA4 = new ClassA4();

        System.out.println("A5---------------");
        ClassA5 classA5 = new ClassA5();

    }

}
