/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assigne;

/**
 *
 * @author T4d3
 */
public class AssignE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("E20---------------");
        ClassE20 classD20 = new ClassE20();
//        classD20.go();

        System.out.println("E21---------------");
        ClassE21 classD21 = new ClassE21();
//        classD21.go();

        System.out.println("E22---------------");
        ClassE22 classE22 = new ClassE22();
        classE22.go();

        System.out.println("E23---------------");
        ClassE23 classD23 = new ClassE23();
//        classD23.go();
    }
}
