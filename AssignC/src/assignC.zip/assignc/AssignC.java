/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignc;

/**
 *
 * @author T4d3
 */
public class AssignC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("C11---------------");
        ClassC11 classC11 = new ClassC11();
//        classC11.go();

        System.out.println("C12---------------");
        ClassC12 classC12 = new ClassC12();
//        classC12.go();

        System.out.println("C13---------------");
        ClassC13 classC13 = new ClassC13();
//        classC13.go();

        System.out.println("C14---------------");
        ClassC14 classC14 = new ClassC14();
//        classC14.go();

        System.out.println("C15---------------");
        ClassC15 classC15 = new ClassC15();
        classC15.go();
    }
}
